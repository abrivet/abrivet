import React from "react";

export const Resume = () => {
    return <div>Resume...</div>;
};
